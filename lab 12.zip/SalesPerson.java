public class SalesPerson {
    String name;
    String city;
    Double commission;
    Double totalSales;
    public SalesPerson(String name, String city, Double totalSales) {
        this.name = name;
        this.city = city;
        this.totalSales = totalSales;
    }
    public String toString(){
        return name + " " + city + " " + totalSales;
    }

}
