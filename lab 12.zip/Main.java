import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Comparator;
import java.util.List;
import java.util.function.*;
import java.util.stream.*;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        String url = "jdbc:mariadb://localhost:3306/labwork";
        String user = "phoenix";
        String password = "207191";
        ArrayList<Customer> customerlist = new ArrayList<>();
        ArrayList<SalesPerson> salespersonlist = new ArrayList<>();
        ArrayList<SalesMan> salesmanlist = new ArrayList<>();
        try {
            Connection conn = DriverManager.getConnection(url, user, password);
            Statement stmt = conn.createStatement();
            String query = "SELECT * FROM customerview";
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                Function<ResultSet, Customer> rsSet = resultSet -> {
                    try {
                        return new Customer(resultSet.getString("Name"),
                                resultSet.getString("City"),
                                Double.parseDouble(resultSet.getString("TotalAmount")));
                    } catch (SQLException e2) {
                        throw new RuntimeException("Error mapping to customer", e2);
                    }
                };
                customerlist.add(rsSet.apply(rs));
            }
            String query2 = "SELECT * FROM salesmanview";
            ResultSet rs2 = stmt.executeQuery(query2);
            while (rs2.next()) {
                Function<ResultSet, SalesPerson> rsSet2 = resultSet ->{
                    try {
                        return new SalesPerson(resultSet.getString("Name"),
                                resultSet.getString("City"),
                                Double.parseDouble(resultSet.getString("TotalAmount")));
                    } catch (SQLException e3){
                        throw new RuntimeException("Error mapping to salesman", e3);
                    }
                };
                salespersonlist.add(rsSet2.apply(rs2));
            }

            String query3 = "SELECT * FROM salesman_orders";
            ResultSet rs3 = stmt.executeQuery(query3);
            while (rs3.next()) {
                Function<ResultSet, SalesMan> rsset3 = resultSet -> {
                    try{
                        return new SalesMan(resultSet.getString("name"),
                                resultSet.getString("city"),
                                resultSet.getDouble("commission"),
                                resultSet.getDouble("total_purchase_amt"));
                    } catch(SQLException e4){
                        throw new RuntimeException("Error mapping to salesperson", e4);
                    }
                };
                salesmanlist.add(rsset3.apply(rs3));
            }



            conn.close();
        } catch (SQLException e) {
            System.err.println("Database connection failed:");
            e.printStackTrace();
        }

        System.out.println("Question 1: print 10 customers");
        System.out.println("customers: ");
        customerlist.stream().limit(10).forEach(System.out::println);
        System.out.println("salespersons: ");
        salespersonlist.stream().limit(10).forEach(System.out::println);
        System.out.println();

        System.out.println("Question 2: use averaging double to get average");
        //customerlist.stream().mapToDouble(n -> n.totalSpent ).average().ifPresent(System.out::println);
        //Doesnt work bc i need saved value
        double customerAvg = customerlist.stream().collect(Collectors.averagingDouble(n -> n.totalSpent));
        System.out.println(customerAvg);
        System.out.println();

        System.out.println("Question 3: create a list of top 10 high spenders");
        List<Double> highSpenders = customerlist.stream().map(n ->n.totalSpent)
                .filter(a ->a > customerAvg)
                .sorted(Comparator.reverseOrder())
                .limit(10).collect(Collectors.toList());
        System.out.println(highSpenders);
        System.out.println();

        System.out.println("Question 4: top 5 cities ");
        List<String> topCities = customerlist.stream().filter(t -> t.totalSpent > customerAvg)
                .sorted(Comparator.comparingDouble((Customer t) -> t.totalSpent).reversed())
                .limit(5)
                .map(t -> t.city)
                .collect(Collectors.toList());
        System.out.println(topCities);


        System.out.printf("%-15s | %-10s%n", "Name", "Total Sales");
        System.out.println("-".repeat(35));
        salesmanlist.stream().forEach(s -> System.out.printf("%-15s | %-10.2f%n", s.name, s.totalSales));
        System.out.println();
        System.out.printf("%-15s | %-10s%n", "Name", "Commission");
        System.out.println("-".repeat(35));
        salesmanlist.stream().forEach(s -> System.out.printf("%-15s | %-10.2f%n", s.name, s.commission));


    }
}