public class SalesMan {
    String name;
    String city;
    Double commission;
    Double totalSales;
    public SalesMan(String name, String city, Double commission, Double totalSales) {
        this.name = name;
        this.city = city;
        this.commission = commission;
        this.totalSales = totalSales;
    }
    public String toString(){
        return name + " " + city + " " + commission + " " + totalSales;
    }
}
