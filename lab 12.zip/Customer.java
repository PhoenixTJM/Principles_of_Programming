import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class Customer {
    String name;
    String city;
    Double totalSpent;

    public Customer(String name, String city, Double totalSpent){
        this.name = name;
        this.city = city;
        this.totalSpent = totalSpent;
    }
    public String toString(){
        return name + " " + city + " " + totalSpent;
    }
}
