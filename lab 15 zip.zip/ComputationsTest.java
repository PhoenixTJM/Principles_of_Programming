import org.example.Computations;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.*;



public class ComputationsTest {
    @Test
    public void testFibonacci(){
        int temp = Computations.fibonacci(5);
        assertEquals(Computations.fibonacci(temp-1)+Computations.fibonacci(temp-2), temp);
    }

    @Test
    public void testPrime(){
        assertTrue(Computations.isPrime(5));
        assertFalse(Computations.isPrime(6));
    }

    @Test
    public void testEven(){
        assertTrue(Computations.isEven(2));
        assertFalse(Computations.isEven(3));
    }

    @Test
    public void testOdd(){
        assertTrue(Computations.isOdd(3));
        assertFalse(Computations.isOdd(4));
    }

    @Test
    public void testCelcius(){
        int temp = 10;
        assertEquals(((temp - 32) * 5.0 / 9.0), Computations.toCelsius(temp));
    }

    @Test
    public void testFahrenheit(){
        int temp = 10;
        assertEquals( ((temp * 9.0 / 5.0) + 32), Computations.toFahrenheit(temp));

    }
}
