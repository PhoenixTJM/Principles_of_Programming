import org.example.Main;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;

import java.util.Arrays;

import static org.example.Main.makeArray;
import static org.example.Main.makeArrayString;
import static org.junit.jupiter.api.Assertions.*;

public class MainTest {

    @Test
    public void testArray() {
        int[] arr = makeArray();
        for (int i = 0; i < arr.length; i++) {
            assertTrue(arr[i] < 20);
        }
    }

    @Test
    public void testStrings(){
        String[] arr = makeArrayString();
        String strOne = arr[0];
        String strTwo = arr[1];
        char[] arrTwo = strOne.toCharArray();
        char[] arrOne = strTwo.toCharArray();
        Arrays.sort(arrOne);
        Arrays.sort(arrTwo);

        assertEquals(Arrays.toString(arrOne), Arrays.toString(arrTwo));
    }
}
