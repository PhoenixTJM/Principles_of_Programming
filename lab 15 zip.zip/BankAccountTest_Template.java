


import org.example.BankAccount;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.*;



class BankAccountTest {

    private BankAccount account;

    @BeforeEach
    void setUp() {
        // Starts each test with a fresh account of 100.0
        account = new BankAccount(100.0);
    }

    /** 1. Add an @AfterEach annotation and method to delete the current bank account to make it available for garbage collection */
    @AfterEach
    void tearDown() {
        account = null;
    }

    @Test
    void testDeposit() {
    /** 2. A deposit $50 and check that the balance is 150 */
     account.deposit(50.0);
     assertEquals(150.0, account.getBalance());
    }

    @Test
    void testWithdraw() {
    /** 3. withdraw $40 and check that the balance is $60; remember that each test is done on a fresh instance of bank account */
    account.withdraw(40.0);
    assertEquals(60.0, account.getBalance());
    }

    @Test
    void testInvalidDeposit() {
    /** 4. Deposit a negative amount and check if an exception is thrown */
    assertThrows(IllegalArgumentException.class, () -> account.deposit(-50.0));
    }

    @Test
    void testOverdraft() {
    /** 5. Verify that Withdrawing more than the current balance
    throws an exception */
    assertThrows(IllegalArgumentException.class, () -> account.withdraw(200));
    }

    @Test
    void testNegativeBalance() {
    /** 6. Add a test to check that an Exception is thrown when
    trying to create a new bankaccout with a negaive initial balance */
    BankAccount account2;
    assertThrows(IllegalArgumentException.class, () -> account = new BankAccount(-100.0));
    account2 = null;
    }

    @Test
    void testTransfer() {
        /**check if the transfer method works */
        BankAccount account2 = new BankAccount(100.0);
        account2.transferMoney(account,50.0);
        assertEquals(50.0, account2.getBalance());
        assertEquals(150.0, account.getBalance());
    }




}
